function initialize()
    % Your code goes here...
end
 